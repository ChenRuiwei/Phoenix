# BitmapAllocator

[![CI](https://github.com/rcore-os/bitmap-allocator/workflows/CI/badge.svg?branch=master)](https://github.com/rcore-os/bitmap-allocator/actions)
[![Coverage Status](https://coveralls.io/repos/github/rcore-os/bitmap-allocator/badge.svg?branch=master)](https://coveralls.io/github/rcore-os/bitmap-allocator?branch=master)

Bit allocator based on segment tree algorithm.
