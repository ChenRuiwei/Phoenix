# BitmapAllocator

[![Crates.io](https://img.shields.io/crates/v/bitmap-allocator)](https://crates.io/crates/bitmap-allocator)
[![Docs.rs](https://docs.rs/bitmap-allocator/badge.svg)](https://docs.rs/bitmap-allocator)
[![CI](https://github.com/rcore-os/bitmap-allocator/actions/workflows/main.yml/badge.svg?branch=main)](https://github.com/rcore-os/bitmap-allocator/actions/workflows/main.yml)
[![Coverage Status](https://coveralls.io/repos/github/rcore-os/bitmap-allocator/badge.svg?branch=master)](https://coveralls.io/github/rcore-os/bitmap-allocator?branch=master)

Bit allocator based on segment tree algorithm.
