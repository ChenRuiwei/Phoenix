//! mcycleh register

read_csr_as_usize_rv32!(0xB80);
