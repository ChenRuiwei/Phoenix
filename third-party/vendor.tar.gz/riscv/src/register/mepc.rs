//! mepc register

read_csr_as_usize!(0x341);
write_csr_as_usize!(0x341);
