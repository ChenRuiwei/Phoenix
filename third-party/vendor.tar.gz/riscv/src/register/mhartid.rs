//! mhartid register

read_csr_as_usize!(0xf14);
