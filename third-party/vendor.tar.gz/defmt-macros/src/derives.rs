//! Procedural macros that are `#[derive(*)]` attributes

pub(crate) mod format;
