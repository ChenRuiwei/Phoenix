//! Procedural macros that are attributes

pub(crate) mod global_logger;
pub(crate) mod panic_handler;
